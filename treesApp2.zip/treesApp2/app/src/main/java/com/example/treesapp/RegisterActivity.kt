package com.example.treesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        auth = FirebaseAuth.getInstance()

        btnRegister.setOnClickListener {
            sinUpUser()
        }
        val btn : TextView =findViewById(R.id.alreadyHaveAccount)
        btn.setOnClickListener({
            val intent = Intent( this, LoginActivity::class.java)
            startActivity(intent)
        })
    }
    private fun sinUpUser() {
        if (inputEmail.text.toString().isEmpty()) {
            inputEmail.error = "Please enter your password"
            inputEmail.requestFocus()
            return
        }
        if (inputEmail.text.toString().isEmpty()) {
            inputEmail.error = "Please enter your email"
            inputEmail.requestFocus()
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(inputEmail.text.toString()).matches()) {
            inputEmail.error = "Please enter a valid email"
            inputEmail.requestFocus()
            return
        }
        if (inputPassword.text.toString().isEmpty()) {
            inputPassword.error = "Please enter your password"
            inputPassword.requestFocus()
            return
        }
        auth.createUserWithEmailAndPassword(inputEmail.text.toString() ,inputPassword.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(baseContext, "Authentication failed. Try Again",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }

}